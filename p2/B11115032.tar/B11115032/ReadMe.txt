執行：在Terminal裏面執行 ./Karno [input pla file] [output pla file]
執行範例：./Karno pla1.pla output1.pla

輸出： output1.pla（執行時輸入的檔案名，位於同一個資料夾）

編譯：在Terminal裏面執行 g++ Karno.cpp -o Karno

