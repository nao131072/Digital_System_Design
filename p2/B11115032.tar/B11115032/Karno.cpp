#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct node{
    string input="";
    char output='0';
    int decimalAmount=0;
    int* decimals=nullptr;
    
    bool foundPair=false; //for simplification
    bool included=false; //for nodes
    bool essential=false; //for primary implicant
    char symbol; //for zako
};

struct one{ //有幾個1
    node* nodes=nullptr; //1000, 0100, 0010, 0001
    int nodeAmount=0;
};

struct bar{ //有幾個-
    one* manyOnes=nullptr; //0個1, 1個1, 2個1, 3個1, 4個1
    int oneAmount=0;
};

bool isExist(string pla, node* nodes, int nodeCount);
bool existInSop(string a, string* Sops, int SopAmount);
int toDecimal(string binary);
bool onlyOneDigitDiff(string a, string b);
node* combineTwoNodes(node a, node b);
bool workInRest(node* nodes, int nodeAmount, node a);
bool newSymbol(string a, char b);
bool allTermsClear(node* nodes, int nodeAmount);
int repeatInPos(string* Poss, int PosAmount, char a);

void completeTerms(string pla, char output, node*& nodes, int &nodeCount, int index=0);
void initializeBars(bar* bars, int inputCount);
void categorizeNodes(node* nodes, int nodeCount, bar* bars, int barCount);
void simplify(bar*& manyBars, int inputCount);
void gatherPrimaryImplicant(bar* manyBars, int inputCount, node*& primaryImplicant, int &PIAmount);
void gatherEPI(node* nodes, int nodeAmount, node* primaryImplicant, int PIAmount, node*& EPI, int &EPIAmount);
void doPatrick(node* nodes, int nodeAmount, node* PI, int PIAmount, node*& zako, int &zakoAmount);
void saveFile(fstream& file, int inputAmount, int outputAmount, char* inputNames, char* outputNames, node* EPI, int EPIAmount, node* zako, int zakoAmount);

int main(int argc, char** argv)
{
    fstream inputFile;
    fstream outputFile;
    
    if(argc!=3){
        cout << "Error: execute format error\n./Karno {input pla file name} {output pla file name}" << endl;
        return 0;
    }
    if(string(argv[1]) == string(argv[2])){
        cout << "Error: input file name and output file name are the same" << endl;
        return 0;
    }
    
    inputFile.open(argv[1], ios::in);
    outputFile.open(argv[2], ios::out);
    
    int inputCount=0, outputCount=0;
    char *inputNames=new char[inputCount];
    char *outputNames=new char[outputCount];
    
    int plaCount=0;
    string *plaInputs=new string[plaCount];
    char *plaOutputs=new char[plaCount];
    
    string prefix="";
    inputFile>>prefix;
    while(prefix != ".e"){
        if(prefix == ".i"){
            inputFile >> inputCount;
            
        }
        else if(prefix == ".o"){
            inputFile >> outputCount;
        }
        else if(prefix == ".ilb"){
            for(int i = 0; i < inputCount; i++){
                inputFile >> inputNames[i];
            }
        }
        else if(prefix == ".ob"){
            for(int i = 0; i < outputCount; i++){
                inputFile >> outputNames[i];
            }
        }
        else if(prefix == ".p"){
            inputFile >> plaCount;
            plaInputs = new string[plaCount];
            plaOutputs = new char[plaCount];
            for (int i = 0; i < plaCount; i++){
                string input;
                char output;
                inputFile >> input >> output;
                plaInputs[i] = input;
                plaOutputs[i] = output;
            }
        }
        else{
            // no .p, direct to pla string and bool
            plaCount++;
            string *tempInputs = new string[plaCount];
            char *tempOutputs = new char[plaCount];
            for (int i = 0; i < plaCount-1; i++){
                tempInputs[i] = plaInputs[i];
                tempOutputs[i] = plaOutputs[i];
            }
            string input="";
            char output;
            input = prefix;
            inputFile >> output;
            tempInputs[plaCount-1] = input;
            tempOutputs[plaCount-1] = output;
            delete[] plaInputs;
            delete[] plaOutputs;
            plaInputs = tempInputs;
            plaOutputs = tempOutputs;
        }
        inputFile >> prefix;
    }
    
    // cout<<plaCount<<endl;
    
    // start here
    int nodeCount=0;
    node* nodes=new node[nodeCount];
    
    for(int i=0;i<plaCount;i++){
        if(plaOutputs[i]=='0') continue;
        completeTerms(plaInputs[i], plaOutputs[i], nodes, nodeCount);
    }
        
    
    //initialize form    
    bar* manyBars=new bar[inputCount]; //0-3 個 bar -
    initializeBars(manyBars, inputCount);  
    categorizeNodes(nodes, nodeCount, manyBars, inputCount); //分類未化簡的node
    
    //simplify
    simplify(manyBars, inputCount);
    
    // cout<<"---------------------------Simplified---------------------------"<<endl;
    // for(int i=0;i<inputCount;i++)
    // {
    //     cout<<i<<"個-"<<endl;
    //     for(int j=0;j<manyBars[i].oneAmount;j++)
    //     {
    //         cout<<j<<"個1: "<<endl;
    //         for(int k=0;k<manyBars[i].manyOnes[j].nodeAmount;k++)
    //         {
    //             cout<<manyBars[i].manyOnes[j].nodes[k].input<<" "<<manyBars[i].manyOnes[j].nodes[k].output<<endl;
    //         }
    //     }
    //     cout<<endl;
    // }
    
    //gather primary implicant
    int PIAmount=0;
    node* primaryImplicant=new node[PIAmount];
    gatherPrimaryImplicant(manyBars, inputCount, primaryImplicant, PIAmount);
    // cout<<"---------------------------Primary Implicant---------------------------"<<endl;
    // for(int i=0;i<PIAmount;i++)
    // {
    //     cout<<primaryImplicant[i].input<<" "<<primaryImplicant[i].output<<" ";
    //     for(int j=0;j<primaryImplicant[i].decimalAmount;j++)
    //     {
    //         cout<<" "<<primaryImplicant[i].decimals[j];
    //     }
    //     cout<<endl;
    // }
    
    //  cout<<"not included: ";
    // for(int i=0;i<nodeCount;i++)
    // {
    //     if(!nodes[i].included && nodes[i].output!='-') cout<<nodes[i].decimals[0]<<" "; 
    // }
    // cout<<endl;
    
    //gather essential primary implicant
    int EPIAmount=0;
    node* EPI=new node[EPIAmount];
    gatherEPI(nodes, nodeCount, primaryImplicant, PIAmount, EPI, EPIAmount);
    // cout<<"---------------------------Essential Primary Implicant---------------------------"<<endl;
    // for(int i=0;i<EPIAmount;i++)
    // {
    //     cout<<EPI[i].input<<" "<<EPI[i].output<<" ";
    //     for(int j=0;j<EPI[i].decimalAmount;j++) cout<<" "<<EPI[i].decimals[j];
    //     cout<<endl;
    // }
    
    if(allTermsClear(nodes, nodeCount)) //提早結束
    {
        // cout<<"---------------------------All Terms Clear---------------------------"<<endl;
        saveFile(outputFile, inputCount, outputCount, inputNames, outputNames, EPI, EPIAmount, nullptr, 0);
        return 0;
    }
    
    // cout<<"not included: ";
    // for(int i=0;i<nodeCount;i++)
    // {
    //     if(!nodes[i].included && nodes[i].output!='-') cout<<nodes[i].decimals[0]<<" "; 
    // }
    // cout<<endl;
    
    // cout<<"---------------------------Symbolize---------------------------"<<endl;
    int symbolCount=0;
    for(int i=0;i<PIAmount;i++)
    {
        if(primaryImplicant[i].essential) continue;
        primaryImplicant[i].symbol='A'+symbolCount;
        // cout<<primaryImplicant[i].symbol<<" = "<<primaryImplicant[i].input<<" ";
        // for(int j=0;j<primaryImplicant[i].decimalAmount;j++) cout<<" "<<primaryImplicant[i].decimals[j];
        // cout<<endl;
        symbolCount++;
    }
    
    int zakoAmount=0;
    node* zako=new node[zakoAmount];
    doPatrick(nodes, nodeCount, primaryImplicant, PIAmount, zako, zakoAmount);
    // cout<<"---------------------------Zako(Patrick)---------------------------"<<endl;
    // cout<<"zakoAmount: "<<zakoAmount<<endl;
    for(int i=0;i<zakoAmount;i++)
    {
        // cout<<zako[i].symbol<<" = "<<zako[i].input<<endl;
        for(int j=0;j<nodeCount;j++)
        {
            if(zako[i].input==nodes[j].input) nodes[j].included=true;
        }
    }
    // cout<<"---------------------------All Terms Clear---------------------------"<<endl;
    saveFile(outputFile, inputCount, outputCount, inputNames, outputNames, EPI, EPIAmount, zako, zakoAmount);
    
    return 0;
}


bool isExist(string pla, node* nodes, int nodeCount)
{
    for(int i=0;i<nodeCount;i++)
    {
        if(pla==nodes[i].input)
        {
            return true;
        }
    }
    return false;
}

void completeTerms(string pla, char output, node*& nodes, int &nodeCount, int index)
{
    if(index==pla.length())
    {
        if(isExist(pla, nodes, nodeCount)) return;
        node* temp=new node[nodeCount+1];
        for(int i=0;i<nodeCount;i++)
        {
            temp[i]=nodes[i];
        }
        temp[nodeCount].input=pla;
        temp[nodeCount].output=output;
        int* tempDecimals=new int[temp[nodeCount].decimalAmount+1];
        for(int i=0;i<temp[nodeCount].decimalAmount;i++)
        {
            tempDecimals[i]=temp[nodeCount].decimals[i];
        }
        tempDecimals[temp[nodeCount].decimalAmount]=toDecimal(pla);
        temp[nodeCount].decimals=tempDecimals;
        temp[nodeCount].decimalAmount++;
        nodes=temp;
        nodeCount++;
        return;
    }
    else
    {
        if(pla[index]=='-')
        {
            string temp = pla;
            temp[index] = '0';
            completeTerms(temp, output, nodes, nodeCount, index+1);
            temp[index] = '1';
            completeTerms(temp, output, nodes, nodeCount, index+1);
        }
        else
        {
            completeTerms(pla, output, nodes, nodeCount, index+1);
        }
    }
}

void initializeBars(bar* bars, int inputCount)
{
    for(int i=0;i<inputCount;i++)
    {
        bars[i].oneAmount=inputCount+1;
        bars[i].manyOnes=new one[inputCount+1];
        for(int j=0;j<inputCount+1;j++)
        {
            bars[i].manyOnes[j].nodeAmount=0;
            bars[i].manyOnes[j].nodes=new node[bars[i].manyOnes[j].nodeAmount];
        }
    }
}

void categorizeNodes(node* nodes, int nodeCount, bar* bars, int barCount)
{
    //put nodes into the 0th bar(not simplified yet)
    for(int i=0;i<nodeCount;i++)
    {
        string input=nodes[i].input;
        int oneCount=0;
        for(int j=0;j<input.length();j++)
        {
            if(input[j]=='1')
            {
                oneCount++;
            }
        }
        
        int oneAmountNow=bars[0].manyOnes[oneCount].nodeAmount;
        node* tempNodes=new node[oneAmountNow+1];
        for(int j=0;j<oneAmountNow;j++)
        {
            tempNodes[j]=bars[0].manyOnes[oneCount].nodes[j];
        }
        tempNodes[oneAmountNow]=nodes[i];
        delete[] bars[0].manyOnes[oneCount].nodes;
        bars[0].manyOnes[oneCount].nodes=tempNodes;
        bars[0].manyOnes[oneCount].nodeAmount++;
    }
}

void simplify(bar*& manyBars, int inputCount)
{
    for(int barCount=0;barCount<inputCount-1;barCount++) //0-2
    {
        bar& barNow=manyBars[barCount];
        bar& toBar=manyBars[barCount+1];
        for(int oneCount=0;oneCount<barNow.oneAmount-1;oneCount++)
        {
            one& oneNow=barNow.manyOnes[oneCount];
            one& targetOne=barNow.manyOnes[oneCount+1];
            for(int i=0;i<oneNow.nodeAmount;i++)
            {
                node& nodeNow=oneNow.nodes[i];
                for(int j=0;j<targetOne.nodeAmount;j++)
                {
                    if(!onlyOneDigitDiff(nodeNow.input, targetOne.nodes[j].input)) continue;
                    node* simplifiedNode=combineTwoNodes(nodeNow, targetOne.nodes[j]);
                    nodeNow.foundPair=true;
                    targetOne.nodes[j].foundPair=true;
                    one& toOne=toBar.manyOnes[oneCount];
                    if(isExist(simplifiedNode->input, toOne.nodes, toOne.nodeAmount)) continue;
                    node* tempNodes=new node[toOne.nodeAmount+1];
                    for(int k=0;k<toOne.nodeAmount;k++)
                    {
                        tempNodes[k]=toOne.nodes[k];
                    }
                    tempNodes[toOne.nodeAmount]=*simplifiedNode;
                    delete[] toOne.nodes;
                    toOne.nodes=tempNodes;
                    toOne.nodeAmount++;
                }
            }
        }
    }
}

void gatherPrimaryImplicant(bar* manyBars, int inputCount, node*& primaryImplicant, int &PIAmount)
{
    for(int b=0;b<inputCount;b++)
    {
        for(int o=0;o<manyBars[b].oneAmount;o++)
        {
            for(int n=0;n<manyBars[b].manyOnes[o].nodeAmount;n++)
            {
                node temp=manyBars[b].manyOnes[o].nodes[n];
                if(!temp.foundPair && temp.output=='1')
                {
                    node* tempNodes=new node[PIAmount+1];
                    for(int i=0;i<PIAmount;i++)
                    {
                        tempNodes[i]=primaryImplicant[i];
                    }
                    tempNodes[PIAmount]=temp;
                    delete[] primaryImplicant;
                    primaryImplicant=tempNodes;
                    PIAmount++;
                }
            }
        }
    }
}

void gatherEPI(node* nodes, int nodeAmount, node* primaryImplicant, int PIAmount, node*& EPI, int &EPIAmount)
{
    for(int i=0;i<nodeAmount;i++)
    {
        if(nodes[i].output!='1') continue;
        if(nodes[i].included) continue;
        int decimal=nodes[i].decimals[0];
        int foundCount=0;
        int foundIndex=0;
        for(int j=0;j<PIAmount;j++)
        {
            for(int k=0;k<primaryImplicant[j].decimalAmount;k++)
            {
                if(decimal==primaryImplicant[j].decimals[k])
                {
                    foundCount++;
                    foundIndex=j;
                }
            }
        }
        
        if(foundCount==1)
        {
            primaryImplicant[foundIndex].essential=true;
            node* tempNodes=new node[EPIAmount+1];
            for(int j=0;j<EPIAmount;j++)
            {
                tempNodes[j]=EPI[j];
            }
            tempNodes[EPIAmount]=primaryImplicant[foundIndex];
            delete[] EPI;
            EPI=tempNodes;
            EPIAmount++;
            for(int j=0;j<primaryImplicant[foundIndex].decimalAmount;j++)
            {
                for(int k=0;k<nodeAmount;k++)
                {
                    if(primaryImplicant[foundIndex].decimals[j]==nodes[k].decimals[0])
                    {
                        nodes[k].included=true;
                    }
                }
            }
        }
    }
}

void doPatrick(node* nodes, int nodeAmount, node* PI, int PIAmount, node*& zako, int &zakoAmount)
{
    //find pos
    int PosAmount=0;
    string* Pos=new string[PosAmount];
    for(int i=0;i<nodeAmount;i++)
    {
        if(nodes[i].included) continue;
        if(nodes[i].output!='1') continue;
        string tempPos="";
        for(int j=0;j<PIAmount;j++)
        {
            if(PI[j].essential) continue;
            if(!workInRest(nodes, nodeAmount, PI[j])) continue;
            for(int k=0;k<PI[j].decimalAmount;k++)
            {
                if(nodes[i].decimals[0]==PI[j].decimals[k])
                {
                    tempPos+=PI[j].symbol;
                    break;
                }
            }
        }
        if(tempPos.length()==0) continue;
        string* tempPoses=new string[PosAmount+1];
        for(int j=0;j<PosAmount;j++) tempPoses[j]=Pos[j];
        tempPoses[PosAmount]=tempPos;
        delete[] Pos;
        Pos=tempPoses;
        PosAmount++;
    }
    
    // cout<<"---------------------------POS---------------------------"<<endl;
    // cout<<"PosAmount: "<<PosAmount<<endl;
    // for(int i=0;i<PosAmount;i++)
    // {
    //     cout<<i<<": "<<Pos[i]<<endl;
    // }

    unsigned int SopAmount=Pos[0].length();
    string* Sop=new string[SopAmount];
    for(int i=0;i<SopAmount;i++) Sop[i]=string(1, Pos[0][i]);
    for(int i=1;i<PosAmount;i++)
    {
        string multipliers=Pos[i];
        unsigned int tempResultAmount=0;
        string* tempResult=new string[tempResultAmount];
        for(int j=0;j<SopAmount;j++)
        {
            for(int k=0;k<multipliers.length();k++)
            {
                if(k>0 && repeatInPos(Pos, PosAmount, multipliers[k])==1) continue;
                string tempSop=Sop[j];
                if(newSymbol(Sop[j], multipliers[k])) tempSop+=string(1, multipliers[k]);
                if(existInSop(tempSop, tempResult, tempResultAmount)) continue;
                string* tempResultTemp=new string[tempResultAmount+1];
                for(int l=0;l<tempResultAmount;l++) tempResultTemp[l]=tempResult[l];
                tempResultTemp[tempResultAmount]=tempSop;
                delete[] tempResult;
                tempResult=tempResultTemp;
                tempResultAmount++;
            }
        }
        delete[] Sop;
        Sop=tempResult;
        SopAmount=tempResultAmount;
    }
    
    // cout<<"---------------------------SOP---------------------------"<<endl;
    // for(int i=0;i<SopAmount;i++)
    // {
    //     cout<<i<<": "<<Sop[i]<<endl;
    // }
    
    int minAmount=Sop[0].length();
    string minProduct=Sop[0];
    for(int i=0;i<SopAmount;i++)
    {
        if(Sop[i].length()<minAmount)
        {
            minAmount=Sop[i].length();
            minProduct=Sop[i];
        }
    }
    
    // cout<<"minProduct: "<<minProduct<<endl;
    
    zakoAmount=minProduct.length();
    zako=new node[zakoAmount];
    for(int i=0;i<zakoAmount;i++)
    {
        for(int j=0;j<PIAmount;j++)
        {
            if(minProduct[i]==PI[j].symbol)
            {
                zako[i]=PI[j];
                // cout<<zako[i].input<<" "<<zako[i].output<<endl;
                break;
            }
        }
    }
    
}

int toDecimal(string binary)
{
    int decimal=0;
    for(int i=0;i<binary.length();i++)
    {
        if(binary[i]=='1')
        {
            decimal+=(1<<(binary.length()-i-1));
        }
    }
    return decimal;
}

bool onlyOneDigitDiff(string a, string b)
{
    if(a.length()!=b.length()) return false;
    int diffCount=0;
    for(int i=0;i<a.length();i++) if(a[i]!=b[i]) diffCount++;
    return diffCount==1;
}

node *combineTwoNodes(node a, node b)
{
    node* resultNode=new node;
    string resultInput=a.input;
    for(int i=0;i<a.input.length();i++)
        if(a.input[i]!=b.input[i]) resultInput[i]='-';
    resultNode->input=resultInput;
    if(a.output=='-' && b.output=='-') resultNode->output='-';
    else resultNode->output='1';
    resultNode->decimals=new int[a.decimalAmount+b.decimalAmount];
    resultNode->decimalAmount=a.decimalAmount+b.decimalAmount;
    for(int i=0;i<a.decimalAmount;i++) resultNode->decimals[i]=a.decimals[i];
    for(int i=0;i<b.decimalAmount;i++) resultNode->decimals[i+a.decimalAmount]=b.decimals[i];
    return resultNode;
}

bool workInRest(node* nodes, int nodeAmount, node a)
{
    bool work=false;
    for(int i=0;i<nodeAmount;i++)
    {
        if(nodes[i].included) continue;
        if(nodes[i].output!='1') continue;
        for(int j=0;j<a.decimalAmount;j++)
            if(nodes[i].decimals[0]==a.decimals[j])
            {   
                work=true;
                break;
            }
    }
    return work;
}

bool newSymbol(string a, char b)
{
    for(int i=0;i<a.length();i++)
    {
        if(a[i]==b) return false;
    }
    return true;
}

bool allTermsClear(node* nodes, int nodeAmount)
{
    for(int i=0;i<nodeAmount;i++)
    {
        if(nodes[i].included) continue;
        if(nodes[i].output!='1') continue;
        return false;
    }
    return true;
}

void saveFile(fstream& file, int inputAmount, int outputAmount, char* inputNames, char* outputNames, node* EPI, int EPIAmount, node* zako, int zakoAmount)
{
    file<<".i "<<inputAmount<<endl;
    file<<".o "<<outputAmount<<endl;
    file<<".ilb ";
    for(int i=0;i<inputAmount;i++) file<<inputNames[i]<<" ";
    file<<endl;
    file<<".ob ";
    for(int i=0;i<outputAmount;i++) file<<outputNames[i]<<" ";
    file<<endl;
    file<<".p "<<EPIAmount+zakoAmount<<endl;
    for(int i=0;i<EPIAmount;i++) file<<EPI[i].input<<" "<<EPI[i].output<<endl;
    for(int i=0;i<zakoAmount;i++) file<<zako[i].input<<" "<<zako[i].output<<endl;
    file<<".e"<<endl;
    
    cout<<"Total number of terms: "<<EPIAmount+zakoAmount<<endl;
    int literalCount=0;
    for(int i=0;i<EPIAmount;i++)
        for(int j=0;j<EPI[i].input.length();j++)
            if(EPI[i].input[j]!='-') literalCount++;
    for(int i=0;i<zakoAmount;i++)
        for(int j=0;j<zako[i].input.length();j++)
            if(zako[i].input[j]!='-') literalCount++;
    cout<<"Total number of literals: "<<literalCount<<endl;
}

bool existInSop(string a, string *Sops, int SopAmount)
{
    for(int i=0;i<SopAmount;i++)
    {
        
        if(a==Sops[i]) return true;
        
        int sameCount=0;
        string &shorter=(a.length()<Sops[i].length())?a:Sops[i];
        string &longer=(a.length()<Sops[i].length())?Sops[i]:a;
        for(int j=0;j<shorter.length();j++)
        {
            for(int k=0;k<longer.length();k++)
            {
                if(shorter[j]==longer[k])
                {
                    sameCount++;
                    break;
                }
            }
        }
        if(sameCount==shorter.length()) return true;
    }
    return false;
}

int repeatInPos(string* Poss, int PosAmount, char a)
{
    int repeatCount=0;
    for(int i=0;i<PosAmount;i++)
    {
        for(int j=0;j<Poss[i].length();j++)
        {
            if(Poss[i][j]==a)
            {
                repeatCount++;
                break;
            }
        }
    }
    return repeatCount;
}
