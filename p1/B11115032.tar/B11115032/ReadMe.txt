執行：在Terminal裏面執行 ./B11115032 [input pla file] [output dot file]
執行範例：./B11115032 pla1.pla output.dot

輸出：output.dot + output.dot.png  （位於同一個資料夾）

編譯：在Terminal裏面執行 g++ B11115032.cpp -o B11115032

