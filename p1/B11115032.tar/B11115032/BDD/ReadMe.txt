執行：在Terminal裏面執行 ./BDD [input pla file] [output dot file]
執行範例：./BDD pla1.pla output.dot

輸出：output.dot + output.dot.png  （位於同一個資料夾）

編譯：在Terminal裏面執行 g++ main.cpp -o BDD

